package main

import (
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"io/ioutil"
	"log"
	"path/filepath"

	"github.com/gocql/gocql"
)

func ErrChk(err error) {
	if err != nil {
		log.Fatalln(err)
	}
}

func main() {
	cqlshrc_host := "d7ddcc21-abe6-4ace-89d7-f04146f5c05e-us-east-1.db.astra.datastax.com"
	cqlshrc_port := "29042"
	username := "token"
	password := "AstraCS:qvGOYRKuPLdhTPTgsysZsrzb:d750a8bad39f2691167e709f3fe3a3430c9bca5b951fghfghfhfghsdf"
	query := "SELECT * FROM keyspace.table"
	cluster := gocql.NewCluster(cqlshrc_host)
	cluster.Authenticator = gocql.PasswordAuthenticator{
		Username: username,
		Password: password,
	}
	cluster.Hosts = []string{cqlshrc_host + ":" + cqlshrc_port}

	certPath, err := filepath.Abs("secure-connect-dbtest/cert")
	ErrChk(err)
	keyPath, err := filepath.Abs("secure-connect-dbtest/key")
	ErrChk(err)
	caPath, err := filepath.Abs("secure-connect-dbtest/ca.crt")
	ErrChk(err)
	cert, err := tls.LoadX509KeyPair(certPath, keyPath)
	ErrChk(err)
	caCert, err := ioutil.ReadFile(caPath)
	ErrChk(err)
	caCertPool := x509.NewCertPool()
	caCertPool.AppendCertsFromPEM(caCert)
	tlsConfig := &tls.Config{
		Certificates: []tls.Certificate{cert},
		RootCAs:      caCertPool,
	}
	cluster.SslOpts = &gocql.SslOptions{
		Config:                 tlsConfig,
		EnableHostVerification: false,
	}

	session, err := cluster.CreateSession()
	if err != nil {
		log.Fatalln(err)
	}
	var key string
	var content string

	fmt.Println("The forecast for all states in the US is:")
	iter := session.Query(query).Iter()
	for iter.Scan(&key, &content) {
		fmt.Printf("\tRank %d: %s, %s\n", key, content)
	}
}
